import MockStore from './mock-store.js'

const store = new MockStore()

