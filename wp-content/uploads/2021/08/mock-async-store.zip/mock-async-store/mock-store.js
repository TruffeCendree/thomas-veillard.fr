import faker from 'faker'

/**
 * A fake store used as a playground for asynchrounous in JS.
 * Delays are simulated using setTimeout to reflet normal HTTP latency.
 */
export default class MockStore {
  /**
   * Find an User by its userName.
   * @param {string} userName 
   * @param {getUserCallback} callback 
   */
  getUserWithCallback (userName, callback) {
    setTimeout(() => {
      if (userName === '404') {
        callback(new Error('Unable to find such user.'), null)
        return
      }

      // 5% risk to returns parent's username that will throw an error when used.
      const parentsAreknown = Math.random() < 0.05

      callback(null, {
        userName,
        email: faker.internet.email(userName),
        phoneNumber: faker.phone.phoneNumber(),
        motherUserName: parentsAreknown ? '404' : faker.internet.userName(),
        fatherUserName: parentsAreknown ? '404' : faker.internet.userName()
      })
    }, 5 + Math.random() * 10)
  }

  /**
   * Find an User by its userName.
   * @param {string} userName
   * @returns {Promise<User>}
   */
  getUserWithPromise (userName) {
    return new Promise((resolve, reject) => {
      this.getUserWithCallback(userName, (err, user) => err ? reject(err) : resolve(user))
    })
  }
}

/**
 * @callback getUserCallback
 * @param {Error} err - The error in case of failure.
 * @param {User} user - The user in case of success.
 * @return {void}
 */

/**
 * @typedef User
 * @property {string} userName
 * @property {string} phoneNumber
 * @property {string} email
 * @property {string} motherUserName
 * @property {string} fatherUserName
 */
