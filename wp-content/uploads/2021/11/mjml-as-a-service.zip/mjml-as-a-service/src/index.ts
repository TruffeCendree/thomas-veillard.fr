import http from 'http'
import mjml from 'mjml'

const server = http.createServer(async (req, res) => {
  try {
    switch(req.url) {
      case '/render':
        await postRender(req, res)
        break
      case '/version':
        await getVersion(req, res)
        break
      default:
        throw new Error(`Unsupported endpoint ${req.url}`)
    }
  } catch (err) {
    const originalMessage = err instanceof Error ? err.message : 'not an instance of Error'
    const formattedErrors = ['Internal Server Error in mjml service', 'Original message was :' + originalMessage]
    res.setHeader('Content-Type', 'application/json')
    res.write(JSON.stringify({ errors: formattedErrors }))
    res.end()
  }
})

const port = parseInt(process.env.PORT || '3000', 10)
server.listen(port, process.env.LISTENED_IP || '127.0.0.1')

/** Render the mjml and send HTTP response */
async function postRender (req: http.IncomingMessage, res: http.ServerResponse) {
  const buffers = []
  for await (const chunk of req) buffers.push(chunk)
  
  const mjmlTemplate = JSON.parse(Buffer.concat(buffers).toString()).template
  const result = mjml(mjmlTemplate, { validationLevel: 'strict' })
  res.setHeader('Content-Type', 'application/json')
  res.write(JSON.stringify({ output: result.html, errors: result.errors }))
  res.end()
}

async function getVersion (req: http.IncomingMessage, res: http.ServerResponse) {
  res.setHeader('Content-Type', 'application/json')
  res.write(JSON.stringify({ version: 4 }))
  res.end()
}
