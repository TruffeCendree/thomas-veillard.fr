import http from 'http'
import mjml from 'mjml'

const server = http.createServer(async (req, res) => {
  try {
    switch(req.url) {
      case '/render':
        await postRender(req, res)
        break
      case '/version':
        await getVersion(req, res)
        break
      default:
        throw new Error(`Unsupported endpoint ${req.url}`)
    }
  } catch (err) {
    const originalMessage = err instanceof Error ? err.message : 'not an instance of Error'
    const formattedErrors = ['Internal Server Error in mjml service', 'Original message was :' + originalMessage]
    res.setHeader('Content-Type', 'application/json')
    res.write(JSON.stringify({ errors: formattedErrors }))
    res.statusCode = 500
    res.end()
  }
})

const port = parseInt(process.env.PORT || '3000', 10)
server.listen(port, process.env.LISTENED_IP || '127.0.0.1')

/** Render the mjml and send HTTP response */
async function postRender (req: http.IncomingMessage, res: http.ServerResponse) {
  const buffers = []
  for await (const chunk of req) buffers.push(chunk)
  
  const mjmlTemplate = Buffer.concat(buffers).toString()
  const result = mjml(mjmlTemplate, { validationLevel: 'strict' })

  if (result.errors.length) {
    res.setHeader('Content-Type', 'application/json')
    res.write(JSON.stringify({ errors: result.errors }))
    res.statusCode = 422 // Unprocessable Entity
  } else {
    res.setHeader('Content-Type', 'text/application')
    res.write(result.html)
  }

  res.end()
}

async function getVersion (req: http.IncomingMessage, res: http.ServerResponse) {
  res.setHeader('Content-Type', 'application/json')
  res.write(JSON.stringify({ version: 4 }))
  res.end()
}
